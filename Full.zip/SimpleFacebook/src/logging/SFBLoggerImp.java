package logging;

public abstract class SFBLoggerImp {

    public abstract void writeOutLine(String text);
    
    public abstract void writeErrorLine(String text);
}
