package models.entities.user;

public class FriendRequest {

}
