package views;

import clients.builder.Style;
import clients.builder.Style.Align;
import controllers.IController;

public class LoginView extends IView {
	public LoginView(IController c) {
		super(c);
	}

	public void login() {
		int page = b.createPage("SimpleFacebook - Login", null);

		int p = b.createParagraph(page, new Style().align(Align.CENTER));
		b.createText(p, "Login Form", new Style().font(30));

		int form = b.createForm(page, "login", "/Check");
		int p1 = b.createParagraph(form, null);
		b.createText(p1, "Login: ", null);
		b.createInput(p1, "email", false, null);
		
		int p2 = b.createParagraph(form, null);
		b.createText(p2, "Password: ", null);
		b.createInput(p2, "passwd", true, null);
		
		b.createFormButton(form, "Login", new Style().width(80).font("Verdana", 14, true));
		
		b.createParagraph(page, new Style().height(50));
		
		b.createButton(page, "Create new user", "/Register", true, new Style());
		
		
	}
}
