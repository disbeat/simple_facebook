package external;

public interface UpdaterAdaptor {
	public void updateStatus(String status);
}
